for numero in range(1, 101):
    print (numero)