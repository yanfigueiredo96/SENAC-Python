#Crie um programa que receba um número inteiro digitado pelo usuário e informe se ele é par ou ímpar.

num1 = int(input('informe um numero inteiro de sua preferencia: '))
if (num1%2==0):
    print('o numero é par')
else:
    print('o numero é impar')