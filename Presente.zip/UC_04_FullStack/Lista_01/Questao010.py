frase = input("Digite uma frase qualquer: ")
quantidade_de_palavras = frase.split()
print(f'A frase que voce digitou tem {len(quantidade_de_palavras)} palavras!')